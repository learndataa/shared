#include "stm32f0xx.h"

#define LEARNING_RATE 0.05f

void ADC_Init(void);
uint16_t ADC_Read(uint8_t channel);
void DAC_Init(void);
void DAC_Write(uint16_t value);
void delay_cycles(uint32_t count);

int main(void)
{
  float weight = 0.5f;

  ADC_Init();
  DAC_Init();

  while (1)
  {
    uint16_t adc_t = ADC_Read(0);  // PA0 - contaminated signal
    uint16_t adc_v = ADC_Read(1);  // PA1 - noise reference

    float t = ((float)adc_t - 2048.0f) / 2048.0f;
    float v = ((float)adc_v - 2048.0f) / 2048.0f;

    float y = weight * v;          // ADALINE's noise prediction
    float error = t - y;           // restored signal

    weight += LEARNING_RATE * error * v;  // LMS update

    uint16_t dac_out = (uint16_t)((y + 1.0f) * 2048.0f);
    if (dac_out > 4095) dac_out = 4095;
    if (dac_out < 0) dac_out = 0;

    DAC_Write(dac_out);

    delay_cycles(8000);  // roughly 1ms loop, ~1kHz update rate
  }
}

void delay_cycles(uint32_t count)
{
  for(volatile uint32_t i = 0; i < count; i++);
}

void ADC_Init(void)
{
  RCC->APB2ENR |= RCC_APB2ENR_ADCEN;
  RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
  GPIOA->MODER |= (3 << (0*2)) | (3 << (1*2));
  ADC1->CR |= ADC_CR_ADEN;
  while (!(ADC1->ISR & ADC_ISR_ADRDY));
}

uint16_t ADC_Read(uint8_t channel)
{
  ADC1->CHSELR = (1 << channel);
  ADC1->CR |= ADC_CR_ADSTART;
  while (!(ADC1->ISR & ADC_ISR_EOC));
  return ADC1->DR;
}

void DAC_Init(void)
{
  RCC->APB1ENR |= RCC_APB1ENR_DACEN;
  RCC->AHBENR |= RCC_AHBENR_GPIOAEN;
  GPIOA->MODER |= (3 << (4*2));  // PA4 analog mode
  DAC->CR |= DAC_CR_EN1;
}

void DAC_Write(uint16_t value)
{
  DAC->DHR12R1 = value;
}